#ifndef STUDENTDELET_H
#define STUDENTDELET_H

#include "main.h"

void delete();//删除学生信息

#endif // !STUDENTDELET_H