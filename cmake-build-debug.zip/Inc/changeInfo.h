#ifndef CHANGEINFO_H
#define CHANGEINFO_H

#include "main.h"

void add();//添加学生信息
void edit();//修改学生信息
int checkoutDormNumAndSex(char *key, char *sex);//检查宿舍号和性别是否匹配

#endif // !CHANGEINFO_H