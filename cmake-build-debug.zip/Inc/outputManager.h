#ifndef OUTPUTMANAGER_H
#define OUTPUTMANAGER_H

#include "main.h"

void writeDataToFile(char *DATA_FILE);
void saveFile();

#endif // !OUTPUTMANAGER_H