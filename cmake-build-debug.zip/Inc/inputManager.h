#ifndef INPUTMANAGER_H
#define INPUTMANAGER_H

#include "main.h"

#endif // !INPUTMANAGER_H